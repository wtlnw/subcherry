package org.tmatesoft.svn.core.auth;

public interface ISVNProxyManagerEx extends ISVNProxyManager {
    
    public char[] getProxyPasswordValue();

}
